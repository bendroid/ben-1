<?php

//---------------------------------------------
// Language file used by mako\utility\Humanizer
//---------------------------------------------

return
[
	'yesterday'   => 'hier',
	'today'       => 'aujourd\'hui',
	'tomorrow'    => 'demain',
	'minute_ago'  => 'il y a une minute',
	'minutes_ago' => 'il y a %u minutes',
	'in_minute'   => 'dans une minute',
	'in_minutes'  => 'dans %u minutes',
];

