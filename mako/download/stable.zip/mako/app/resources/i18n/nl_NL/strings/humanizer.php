<?php

//---------------------------------------------
// Language file used by mako\utility\Humanizer
//---------------------------------------------

return
[
	'yesterday'   => 'gisteren',
	'today'       => 'vandaag',
	'tomorrow'    => 'morgen',
	'minute_ago'  => 'een minuut geleden',
	'minutes_ago' => '%u minuten geleden',
	'in_minute'   => 'in een minuut',
	'in_minutes'  => 'in %u minuten',
];

