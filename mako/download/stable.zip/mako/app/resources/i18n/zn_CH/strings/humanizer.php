<?php

//---------------------------------------------
// Language file used by mako\utility\Humanizer
//---------------------------------------------

return
[
	'yesterday'   => '昨天',
	'today'       => '今天',
	'tomorrow'    => '明天',
	'minute_ago'  => '一分钟前',
	'minutes_ago' => '%u分钟前',
	'in_minute'   => '在一分钟',
	'in_minutes'  => '在%u分钟',
];

