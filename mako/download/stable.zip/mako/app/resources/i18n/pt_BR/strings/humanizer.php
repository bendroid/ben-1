<?php

//---------------------------------------------
// Language file used by mako\utility\Humanizer
//---------------------------------------------

return
[
	'yesterday'   => 'ontem',
	'today'       => 'hoje',
	'tomorrow'    => 'amanhã',
	'minute_ago'  => 'um minuto atrás',
	'minutes_ago' => '%u minutos atrás',
	'in_minute'   => 'em um minuto',
	'in_minutes'  => 'em %u minutos',
];